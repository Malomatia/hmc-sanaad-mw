import { INestApplication, ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Reflector } from '@nestjs/core';
import { ResponseInterceptor } from '@core/http/response.interceptor';
import { JwtService } from '@nestjs/jwt';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { JwtAuthGuard } from '@core/auth/jwt-auth.guard';
import { JwtStrategy } from '@core/auth/jwt.strategy';
import { AuthStateService } from '@core/auth/auth-state.service';
import { TokenRevocationService } from '@core/auth/token-revocation.service';
import { OracleService } from '@core/database/oracle.service';
import { OracleSchemaService } from '@core/database/oracle-schema.service';
import { LookupsService } from '../../application/lookups.service';
import { LOV_REPOSITORY } from '../../domain/lov.repository';
import { LookupsController } from '../../interface/lookups.controller';
import { LovOracleRepository } from './lov.oracle.repository';
import { OracleContractCatalog } from '@core/database/oracle-contracts';
import { OracleContractUnavailableException } from '@core/database/oracle.error';
import { ORACLE_OBJECTS } from '@shared/constants/oracle-objects';
import { LettersService } from '@modules/letters/application/letters.service';
import { DependentService, PassportService } from '@modules/dependents/application/dependents.service';
import { DEPENDENT_REPOSITORY } from '@modules/dependents/domain/dependents.repository';
import { DependentsController } from '@modules/dependents/interface/dependents.controller';

describe('Static LOV contracts', () => {
  function make() {
    const query = jest.fn().mockResolvedValue([]);
    const schema = new OracleSchemaService(new OracleContractCatalog());
    const config = { get: jest.fn().mockReturnValue(0) } as unknown as ConfigService;
    return { query, repo: new LovOracleRepository({ query } as unknown as OracleService, schema, config) };
  }

  it('uses a registered person-id filter without any dictionary query', async () => {
    const { repo, query } = make();
    await repo.readLov(ORACLE_OBJECTS.LEAVE_CANCEL_V, 'en', 'TESTUSER', { personId: '123' });
    expect(query).toHaveBeenCalledTimes(1);
    expect(query).toHaveBeenCalledWith(
      'SELECT * FROM XXHMC_SND_LEAVE_CANCEL_V WHERE person_id = :personId',
      { personId: '123' },
    );
  });

  it('does not widen a personal read when no identifier can match its key type', async () => {
    const { repo, query } = make();
    await expect(repo.readLov(ORACLE_OBJECTS.LEAVE_CANCEL_V, 'en', 'TESTUSER')).resolves.toEqual([]);
    expect(query).not.toHaveBeenCalled();
  });

  it('requires a caller identifier for known personal LOVs', async () => {
    const { repo, query } = make();
    await expect(repo.readLov(ORACLE_OBJECTS.LEAVE_CANCEL_V, 'en')).rejects.toMatchObject({ status: 400 });
    expect(query).not.toHaveBeenCalled();
  });

  it('does not query an unfiltered view when its static scope contract is missing', async () => {
    const { repo, query } = make();
    await expect(repo.readLov(ORACLE_OBJECTS.ANNUAL_TICKT_LOV, 'en', 'TESTUSER'))
      .rejects.toBeInstanceOf(OracleContractUnavailableException);
    expect(query).not.toHaveBeenCalled();
  });

  it.each([
    ['ALSR_DEFAULT_LOV', ORACLE_OBJECTS.ALSR_DFALT_LOV],
    ['LIBR_DEFAULT_LOV', ORACLE_OBJECTS.LIBR_DFALT_LOV],
    ['ALSR_DFALT_LOV', ORACLE_OBJECTS.ALSR_DFALT_LOV],
    ['LIBR_DFALT_LOV', ORACLE_OBJECTS.LIBR_DFALT_LOV],
  ])('reads the confirmed default columns for %s without caller filtering', async (name, object) => {
    const { repo, query } = make();
    const service = new LookupsService(repo);
    query.mockResolvedValue([{ DEFAULT_VALUE: 'No', DEFAULT_VALUE_AR: 'لا' }]);
    const expected = [{ code: 'No', meaning: 'No', meaningAr: 'لا', used_value: 'No' }];

    await expect(service.getLov(name, 'en', 'TESTUSER')).resolves.toEqual(expected);
    await expect(service.getLov(name, 'en')).resolves.toEqual(expected);
    await expect(service.getLov(name, 'ar', 'TESTUSER', '123')).resolves.toEqual(expected);
    expect(query).toHaveBeenCalledTimes(3);
    for (const call of query.mock.calls) {
      expect(call).toEqual([`SELECT * FROM ${object}`, {}]);
    }
  });

  it('keeps a global country lookup as a direct view query', async () => {
    const { repo, query } = make();
    await repo.readLov(ORACLE_OBJECTS.COUNTRY_LOV, 'en');
    expect(query).toHaveBeenCalledWith('SELECT * FROM XXHMC_SND_COUNTRY_LOV', {});
  });
});

const object = 'XXHMC_SND_SCHOOL_NAME_LOV';

describe('LovOracleRepository', () => {
  function make() {
    const query = jest.fn().mockResolvedValue([{ NAME: 'Doha School', USER_NAME: 'V-TEST' }]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest.fn().mockImplementation((_object: string, column: string) =>
      Promise.resolve(['USER_NAME', 'NAME'].includes(column.toUpperCase())),
    );
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = {
      get: jest.fn().mockReturnValue(300000),
    } as unknown as ConfigService;
    return { repository: new LovOracleRepository(ora, schema, config), query };
  }

  it('applies the user filter, search, and bounded Oracle pagination', async () => {
    const { repository, query } = make();
    const items = await repository.readLov(object, 'en', 'V-TEST', {
      search: 'doha',
      offset: 100,
      limit: 100,
    });
    expect(items).toEqual([expect.objectContaining({ meaning: 'Doha School' })]);
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining(
        'WHERE user_name IN (:u0) AND UPPER(NAME) LIKE :search ORDER BY 1 OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY',
      ),
      { u0: 'V-TEST', search: '%DOHA%', offset: 100, limit: 100 },
    );
  });

  it.each(['en', 'ar'] as const)(
    'preserves academic-year dates and existing LOV fields for lang=%s, including cached reads',
    async (lang) => {
      const { repository, query } = make();
      query.mockResolvedValue([
        { ACAD_YEAR: '2025-2026', ACD_STARD_DT: '01-SEP-2025', ACD_END_DT: '30-JUN-2026' },
        { ACAD_YEAR: '2026-2027', ACD_STARD_DT: '01-SEP-2026', ACD_END_DT: '30-JUN-2027' },
      ]);

      const items = await repository.readLov('XXHMC_SND_ACAD_YR_STRT_END_LOV', lang);

      expect(items).toEqual([
        {
          code: '2025-2026',
          meaning: '2025-2026',
          used_value: '2025-2026',
          ACCAD_YEAR: '2025-2026',
          ACD_START_DT: '01-SEP-2025',
          ACD_END_DT: '30-JUN-2026',
        },
        {
          code: '2026-2027',
          meaning: '2026-2027',
          used_value: '2026-2027',
          ACCAD_YEAR: '2026-2027',
          ACD_START_DT: '01-SEP-2026',
          ACD_END_DT: '30-JUN-2027',
        },
      ]);
      expect(query).toHaveBeenCalledWith('SELECT * FROM XXHMC_SND_ACAD_YR_STRT_END_LOV', {});
      await expect(repository.readLov('XXHMC_SND_ACAD_YR_STRT_END_LOV', lang)).resolves.toEqual(
        items,
      );
      expect(query).toHaveBeenCalledTimes(1);
    },
  );

  it.each(['en', 'ar'] as const)(
    'uses the record id only for RFL_LEAVE_DET_LOV with lang=%s, including cached reads',
    async (lang) => {
      const { repository, query } = make();
      const service = new LookupsService(repository);
      const label =
        'Annual Leave|Leave Start Date : 04-SEP-2026 and Leave End Date : 18-SEP-2026';
      query.mockResolvedValue([
        { USER_NAME: 'V-TEST', LEAVE: label, ABSENCE_ATTENDANCE_ID: 56990954 },
        { USER_NAME: 'V-TEST', LEAVE: label, ABSENCE_ATTENDANCE_ID: '56990955' },
      ]);
      const expected = ['56990954', '56990955'].map((id) => ({
        code: label,
        meaning: label,
        used_value: id,
        id,
      }));

      await expect(service.getLov('RFL_LEAVE_DET_LOV', lang, 'V-TEST')).resolves.toEqual(
        expected,
      );
      await expect(service.getLov('RFL_LEAVE_DET_LOV', lang, 'V-TEST')).resolves.toEqual(
        expected,
      );
      expect(query).toHaveBeenCalledTimes(1);
      expect(query).toHaveBeenCalledWith(
        'SELECT * FROM XXHMC_SND_RFL_LEAVE_DET_V WHERE user_name IN (:u0)',
        { u0: 'V-TEST' },
      );

      for (const lovname of ['RFL_REL_LEAVE1_LOV', 'RFL_REL_LEAVE2_LOV']) {
        await expect(service.getLov(lovname, lang, 'V-TEST')).resolves.toEqual(
          expected.map((item) => ({ ...item, used_value: label })),
        );
      }
    },
  );

  it('preserves the existing value when a return-from-leave detail has no id', async () => {
    const { repository, query } = make();
    query.mockResolvedValue([{ LEAVE: 'Annual Leave', ABSENCE_ATTENDANCE_ID: null }]);

    await expect(
      repository.readLov(ORACLE_OBJECTS.RFL_LEAVE_DET_V, 'en', 'V-TEST'),
    ).resolves.toEqual([
      { code: 'Annual Leave', meaning: 'Annual Leave', used_value: 'Annual Leave' },
    ]);
  });

  it('does not add academic-year fields to a different LOV', async () => {
    const { repository, query } = make();
    query.mockResolvedValue([
      { NAME: 'Doha School', ACAD_YEAR: '2025-2026', ACD_STARD_DT: '01-SEP-2025' },
    ]);

    const [item] = await repository.readLov(object, 'en', 'V-TEST');

    expect(item.code).toBe('Doha School');
    expect(item).not.toHaveProperty('ACCAD_YEAR');
    expect(item).not.toHaveProperty('ACD_START_DT');
    expect(item).not.toHaveProperty('ACD_END_DT');
  });

  it('uppercases username scopes, preserving employee numbers and input options', async () => {
    const { repository, query } = make();
    const options = { scopeAlternatives: ['other.User', '0037400'] };
    await repository.readLov(object, 'en', 'mixed.User', options);
    expect(query).toHaveBeenCalledWith(expect.any(String), {
      u0: 'MIXED.USER',
      u1: 'OTHER.USER',
      u2: '0037400',
    });
    expect(options.scopeAlternatives).toEqual(['other.User', '0037400']);
  });

  it('coalesces and caches identical LOV requests', async () => {
    const { repository, query } = make();
    await Promise.all([
      repository.readLov(object, 'en', 'V-TEST'),
      repository.readLov(object, 'en', 'V-TEST'),
    ]);
    await repository.readLov(object, 'en', 'V-TEST');
    expect(query).toHaveBeenCalledTimes(1);
  });

  describe('letters LOV cache bypass', () => {
    const objects = [
      ORACLE_OBJECTS.LETTER_MOBILE_NO_LOV,
      ORACLE_OBJECTS.EMP_LTR_DEFAULT_COPY,
      ORACLE_OBJECTS.LETTER_COUNTRY_LOV,
      ORACLE_OBJECTS.LETTER_NAME_LOV,
      ORACLE_OBJECTS.LETTER_LANGUAGE_LOV,
      ORACLE_OBJECTS.EXIT_COPIES_LOV,
      ORACLE_OBJECTS.DELIVERY_LOC_V,
    ];
    const keys = [
      'mobileNo', 'defaultCopy', 'country', 'name', 'language', 'exitCopies', 'deliveryLoc',
    ];

    it.each(['en', 'ar'] as const)(
      'refreshes all seven lists for lang=%s without reading or replacing shared caches',
      async (lang) => {
        const { repository, query } = make();
        const lookups = new LookupsService(repository);
        const letters = new LettersService({ submit: jest.fn() }, lookups);
        const readShared = () =>
          Promise.all(objects.map((lov, index) =>
            index === 0
              ? lookups.getByObject(lov, lang, '037400', { scopeAlternatives: ['V-TEST'] })
              : lookups.getByObject(lov, lang),
          ));
        query.mockResolvedValue([{ NAME: 'Cached value' }]);
        const cached = await readShared();

        for (const value of ['First fresh value', 'Second fresh value']) {
          query.mockResolvedValue([{ NAME: value }]);
          const result = await letters.getLetterLovs(lang, '037400', 'V-TEST');
          expect(Object.keys(result)).toEqual(keys);
          for (const key of keys) {
            expect(result[key]).toEqual([
              { code: value, meaning: value, used_value: value },
            ]);
          }
        }

        expect(query).toHaveBeenCalledTimes(21);
        expect(query).toHaveBeenCalledWith(
          `SELECT * FROM ${ORACLE_OBJECTS.LETTER_MOBILE_NO_LOV} WHERE user_name IN (:u0, :u1)`,
          { u0: '037400', u1: 'V-TEST' },
        );
        for (const lov of objects) {
          expect(query.mock.calls.filter(([sql]) => sql.startsWith(`SELECT * FROM ${lov}`))).toHaveLength(3);
        }
        await expect(readShared()).resolves.toEqual(cached);
        expect(query).toHaveBeenCalledTimes(21);
      },
    );

    it('does not coalesce letters requests or populate shared lookup caches', async () => {
      const { repository, query } = make();
      const lookups = new LookupsService(repository);
      const letters = new LettersService({ submit: jest.fn() }, lookups);
      await Promise.all([
        letters.getLetterLovs('en', '037400', 'V-TEST'),
        letters.getLetterLovs('en', '037400', 'V-TEST'),
      ]);
      expect(query).toHaveBeenCalledTimes(14);

      for (const lov of objects.slice(1)) {
        await lookups.getByObject(lov, 'en');
        await lookups.getByObject(lov, 'en');
      }
      expect(query).toHaveBeenCalledTimes(20);
    });
  });

  it('filters the multi-type LOV by its grouping column when dataType is passed (DEP_LOOKUP_LOV)', async () => {
    const query = jest.fn().mockResolvedValue([{ CODE: 'C', DATA: 'Child', D_DATA_TYPE: 'CONTACT' }]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(c.toUpperCase() === 'D_DATA_TYPE'));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    const items = await repository.readLov('XXHMC_SND_DEP_LOOKUP_LOV', 'en', undefined, {
      dataType: 'contact',
    });

    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('WHERE UPPER(D_DATA_TYPE) = :dataType'),
      { dataType: 'CONTACT' },
    );
    expect(items).toEqual([expect.objectContaining({ code: 'C', meaning: 'Child', type: 'CONTACT' })]);
  });

  it('filters the reasons LOV by its LEAVE_TYPE column when leaveType is passed (ABSENCE_REASON_V)', async () => {
    const query = jest
      .fn()
      .mockResolvedValue([
        { LEAVE_TYPE: 'Compassionate Leave', LEAVE_REASON: 'Death of 2nd Degree Relative' },
      ]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(c.toUpperCase() === 'LEAVE_TYPE'));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    const items = await repository.readLov('XXHMC_SND_ABSENCE_REASON_V', 'en', undefined, {
      leaveType: 'Compassionate Leave',
    });

    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('WHERE UPPER(LEAVE_TYPE) = :leaveType'),
      { leaveType: 'COMPASSIONATE LEAVE' },
    );
    expect(items).toEqual([
      expect.objectContaining({ meaning: 'Death of 2nd Degree Relative' }),
    ]);
  });

  it('filters on NAME when the view has no dedicated leave-type column (LEAVE_CANCEL_V, ops 61/62)', async () => {
    const query = jest
      .fn()
      .mockResolvedValue([{ NAME: 'Casual Leave', VALUE: 'Casual Leave|19-APR-2026|19-APR-2026' }]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) =>
        Promise.resolve(['NAME', 'PERSON_ID'].includes(c.toUpperCase())),
      );
    // PERSON_ID really is a NUMBER on this view
    const schema = {
      hasColumn,
      isNumericColumn: jest.fn().mockResolvedValue(true),
    } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_LEAVE_CANCEL_V', 'en', '26023', {
      leaveType: 'Casual Leave',
      scopeAlternatives: ['AIBRAHIM39'],
    });

    // NAME holds display strings ("Casual Leave|19-APR-2026|…") → contains
    // match. Only the numeric identifier reaches PERSON_ID: this case used to
    // offer the username too, and Oracle then rejected the entire IN-list
    // (ORA-01722), so the view's 15 rows came back as 0.
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('UPPER(NAME) LIKE :leaveType'),
      expect.objectContaining({ u0: '26023', leaveType: '%CASUAL LEAVE%' }),
    );
    expect((query.mock.calls[0] as unknown[])[0]).toContain('IN (:u0)');
    expect(query.mock.calls[0][1]).not.toHaveProperty('u1');
  });

  it('falls back to the employee-number column when the view has no user column (LEAVE_AMEND_V)', async () => {
    const query = jest.fn().mockResolvedValue([]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(c.toUpperCase() === 'EMPLOYEE_NUMBER'));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_LEAVE_AMEND_V', 'en', '053613');

    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('WHERE employee_number IN (:u0)'),
      { u0: '053613' },
    );
  });

  it('matches leave_type case-insensitively (lowercase input, any column case)', async () => {
    const query = jest.fn().mockResolvedValue([]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(['NAME', 'PERSON_ID'].includes(c.toUpperCase())));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(true) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_LEAVE_CANCEL_V', 'en', '123', {
      leaveType: '  casual leave ',
    });

    // Input is trimmed + upper-cased, and the column is wrapped in UPPER() —
    // so the match is case-insensitive on both sides.
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('UPPER(NAME) LIKE :leaveType'),
      { u0: '123', leaveType: '%CASUAL LEAVE%' },
    );
  });

  it('filters a person-scoped view by PERSON_ID when personId is passed (CONTRACT_YEARS_V)', async () => {
    const query = jest.fn().mockResolvedValue([{ CONTRACT_YEAR: '2026' }]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(c.toUpperCase() === 'PERSON_ID'));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_CONTRACT_YEARS_V', 'en', undefined, {
      personId: ' 852709 ',
    });

    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('WHERE person_id = :personId'),
      { personId: '852709' },
    );
  });

  it('ignores personId when the view has no PERSON_ID column', async () => {
    const query = jest.fn().mockResolvedValue([]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest.fn().mockResolvedValue(false);
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_YES_NO_LOV', 'en', undefined, { personId: '852709' });

    expect(query).toHaveBeenCalledWith(expect.not.stringContaining('WHERE'), {});
  });

  it('keeps the exact match on a dedicated LEAVE_TYPE column (op 13 unchanged)', async () => {
    const query = jest.fn().mockResolvedValue([]);
    const ora = { query } as unknown as OracleService;
    const hasColumn = jest
      .fn()
      .mockImplementation((_o: string, c: string) => Promise.resolve(c.toUpperCase() === 'LEAVE_TYPE'));
    const schema = { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) } as unknown as OracleSchemaService;
    const config = { get: jest.fn().mockReturnValue(300000) } as unknown as ConfigService;
    const repository = new LovOracleRepository(ora, schema, config);

    await repository.readLov('XXHMC_SND_ABSENCE_REASON_V', 'en', undefined, {
      leaveType: 'Casual Leave',
    });

    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('UPPER(LEAVE_TYPE) = :leaveType'),
      { leaveType: 'CASUAL LEAVE' },
    );
  });
});

describe('Localized LOV HTTP responses', () => {
  const path = '/api/v1/lookups/lov';
  const secret = 'default-lov-test-secret-not-for-production';
  const token = new JwtService({ secret, signOptions: { expiresIn: '1h', issuer: 'sanaad', audience: 'sanaad-b2e', algorithm: 'HS256' } })
    .sign({ sub: '037400', sid: 'test-session', jti: 'test-access', deviceImei: 'test-device', typ: 'access', username: 'TESTUSER', employeeNumber: '037400' });
  const query = jest.fn();
  let app: INestApplication;

  beforeAll(async () => {
    const config = {
      get: (key: string, fallback: unknown) => (key === 'app.lovCacheTtlMs' ? 0 : fallback),
      getOrThrow: () => ({ jwtSecret: secret, jwtIssuer: 'sanaad', jwtAudience: 'sanaad-b2e' }),
    };
    const moduleRef = await Test.createTestingModule({
      controllers: [LookupsController, DependentsController],
      providers: [
        LookupsService,
        DependentService,
        { provide: DEPENDENT_REPOSITORY, useValue: {} },
        { provide: PassportService, useValue: {} },
        JwtAuthGuard,
        JwtStrategy,
        TokenRevocationService,
        { provide: AuthStateService, useValue: { sessionActive: jest.fn().mockResolvedValue(true) } },
        OracleContractCatalog,
        OracleSchemaService,
        { provide: LOV_REPOSITORY, useClass: LovOracleRepository },
        { provide: OracleService, useValue: { query } },
        { provide: ConfigService, useValue: config },
      ],
    }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(
      new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
    );
    app.useGlobalGuards(app.get(JwtAuthGuard));
    app.useGlobalInterceptors(new ResponseInterceptor(new Reflector()));
    await app.init();
  });

  beforeEach(() => {
    query.mockReset().mockResolvedValue([{ DEFAULT_VALUE: 'No', DEFAULT_VALUE_AR: 'لا' }]);
  });

  afterAll(async () => {
    await app?.close();
  });

  it.each([
    ['ALSR_DEFAULT_LOV', 'XXHMC_SND_ALSR_DFALT_LOV', 'en'],
    ['ALSR_DEFAULT_LOV', 'XXHMC_SND_ALSR_DFALT_LOV', 'ar'],
    ['LIBR_DEFAULT_LOV', 'XXHMC_SND_LIBR_DFALT_LOV', 'en'],
    ['LIBR_DEFAULT_LOV', 'XXHMC_SND_LIBR_DFALT_LOV', 'ar'],
  ])('returns %s in %s with lang=%s using its static contract', async (lovname, object, lang) => {
    for (const scope of [{}, { username: 'TESTUSER', person_id: '123' }]) {
      await request(app.getHttpServer())
        .get(path)
        .query({ lovname, lang, ...scope })
        .set('Authorization', `Bearer ${token}`)
        .expect(200)
        .expect({
          result: { items: [{ code: 'No', meaning: lang === 'ar' ? 'لا' : 'No', used_value: 'No' }] },
          opstatus: 0,
          status: 'success',
          httpStatusCode: 200,
        });
    }
    expect(query).toHaveBeenCalledTimes(2);
    for (const call of query.mock.calls) {
      expect(call).toEqual([`SELECT * FROM ${object}`, {}]);
    }
  });

  it.each(['ALSR_DEFAULT_LOV', 'LIBR_DEFAULT_LOV'])(
    'keeps English fallback and empty results for %s',
    async (lovname) => {
      query.mockResolvedValueOnce([{ DEFAULT_VALUE: 'No', DEFAULT_VALUE_AR: null }]);
      const fallback = await request(app.getHttpServer())
        .get(path)
        .query({ lovname, lang: 'ar' })
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(fallback.body.result.items).toEqual([{ code: 'No', meaning: 'No', used_value: 'No' }]);

      query.mockResolvedValueOnce([]);
      const empty = await request(app.getHttpServer())
        .get(path)
        .query({ lovname, lang: 'en' })
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(empty.body.result.items).toEqual([]);
    },
  );

  describe.each([
    ['EMPLOYMENT_STATUS_V', 'FLEX_VALUE', 'Active', 'نشط'],
    ['EMP_MARITAL_LOV', 'MARITAL_STATUS', 'Married', 'متزوج'],
  ])('%s label language', (lovname, field, en, ar) => {
    it.each(['en', 'ar', undefined])('returns meaning for lang=%s', async (lang) => {
      const row = Object.freeze({ [`${field}_AR`]: encodeURIComponent(ar), [field]: en });
      query.mockResolvedValue([row]);
      const req = request(app.getHttpServer())
        .get(path)
        .query({ lovname })
        .set('Authorization', `Bearer ${token}`);
      if (lang !== undefined) req.query({ lang });
      await req.expect(200).expect({
        result: { items: [{ code: en, meaning: lang === 'ar' ? ar : en, used_value: en }] },
        opstatus: 0,
        status: 'success',
        httpStatusCode: 200,
      });
      expect(query).toHaveBeenCalledWith(`SELECT * FROM XXHMC_SND_${lovname}`, {});
      expect(row[`${field}_AR`]).toBe(encodeURIComponent(ar));
    });

    it.each([null, undefined, ''])('keeps English when the Arabic column is %s', async (label) => {
      query.mockResolvedValue([{ [field]: en, [`${field}_AR`]: label }]);
      const response = await request(app.getHttpServer())
        .get(path)
        .query({ lovname, lang: 'ar' })
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(response.body.result.items).toEqual([{ code: en, meaning: en, used_value: en }]);
    });
  });

  it('decodes an encoded ALSR Arabic default while retaining the English submit value', async () => {
    query.mockResolvedValueOnce([{ DEFAULT_VALUE: 'No', DEFAULT_VALUE_AR: encodeURIComponent('لا') }]);
    const response = await request(app.getHttpServer())
      .get(path)
      .query({ lovname: 'ALSR_DEFAULT_LOV', lang: 'ar' })
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    expect(response.body.result.items).toEqual([{ code: 'No', meaning: 'لا', used_value: 'No' }]);
  });

  describe.each(['en', 'ar'])('dependent LOV lang=%s', (lang) => {
    it.each([undefined, '', 'sponsorship'])(
      'selects the requested label with data_type=%s and preserves submit values',
      async (dataType) => {
        query.mockResolvedValue([{
          D_DATA_TYPE: 'SPONSORSHIP',
          D_DATA: 'Employee',
          D_DATA_AR: encodeURIComponent('الموظف'),
        }]);
        const req = request(app.getHttpServer())
          .get('/api/v1/dependents/lov')
          .query({ lang })
          .set('Authorization', `Bearer ${token}`);
        if (dataType !== undefined) req.query({ data_type: dataType });

        await req.expect(200).expect({
          result: {
            items: [{
              code: 'Employee',
              meaning: lang === 'ar' ? 'الموظف' : 'Employee',
              used_value: 'Employee',
              type: 'SPONSORSHIP',
            }],
          },
          opstatus: 0,
          status: 'success',
          httpStatusCode: 200,
        });
        expect(query).toHaveBeenCalledTimes(1);
        expect(query).toHaveBeenCalledWith(
          `SELECT * FROM XXHMC_SND_DEP_LOOKUP_LOV${dataType ? ' WHERE UPPER(D_DATA_TYPE) = :dataType' : ''}`,
          dataType ? { dataType: 'SPONSORSHIP' } : {},
        );
      },
    );
  });

  it.each([undefined, null, ''])('keeps English when the dependent Arabic label is %s', async (label) => {
    query.mockResolvedValueOnce([{
      D_DATA: 'Employee', D_DATA_AR: label, D_DATA_TYPE: 'SPONSORSHIP',
    }]);

    await request(app.getHttpServer())
      .get('/api/v1/dependents/lov?lang=ar&data_type=')
      .set('Authorization', `Bearer ${token}`)
      .expect(200)
      .expect(({ body }) => expect(body.result.items).toEqual([{
        code: 'Employee', meaning: 'Employee', used_value: 'Employee', type: 'SPONSORSHIP',
      }]));
  });

  it('keeps dependent LOV authentication required', async () => {
    await request(app.getHttpServer())
      .get('/api/v1/dependents/lov?lang=ar&data_type=')
      .expect(401);
    expect(query).not.toHaveBeenCalled();
  });

  it.each(['ALSR_DEFAULT_LOV', 'LIBR_DEFAULT_LOV'])(
    'still requires authentication for %s',
    async (lovname) => {
      await request(app.getHttpServer()).get(path).query({ lovname }).expect(401);
      expect(query).not.toHaveBeenCalled();
    },
  );
});

describe('CONTRACT_YEARS_V authenticated lookup', () => {
  const path = '/api/v1/lookups/lov';
  const secret = 'contract-years-test-secret-not-for-production';
  const jwt = new JwtService({ secret, signOptions: { expiresIn: '1h', issuer: 'sanaad', audience: 'sanaad-b2e', algorithm: 'HS256' } });
  const tokenFor = (username: string) => jwt.sign({ sub: '037400', sid: 'test-session', jti: 'test-access',
    deviceImei: 'test-device', typ: 'access', username, employeeNumber: '037400' });
  let app: INestApplication;
  let query: jest.Mock;
  let hasColumn: jest.Mock;

  beforeEach(async () => {
    query = jest.fn().mockResolvedValue([{ CONTRACT_YEAR: '2026' }]);
    hasColumn = jest.fn().mockResolvedValue(true);
    const config = {
      get: (key: string, fallback: unknown) => (key === 'app.lovCacheTtlMs' ? 300000 : fallback),
      getOrThrow: () => ({ jwtSecret: secret, jwtIssuer: 'sanaad', jwtAudience: 'sanaad-b2e' }),
    };
    const moduleRef = await Test.createTestingModule({
      controllers: [LookupsController],
      providers: [
        LookupsService,
        JwtAuthGuard,
        JwtStrategy,
        TokenRevocationService,
        { provide: AuthStateService, useValue: { sessionActive: jest.fn().mockResolvedValue(true) } },
        { provide: LOV_REPOSITORY, useClass: LovOracleRepository },
        { provide: OracleService, useValue: { query } },
        {
          provide: OracleSchemaService,
          useValue: { hasColumn, isNumericColumn: jest.fn().mockResolvedValue(false) },
        },
        { provide: ConfigService, useValue: config },
      ],
    }).compile();
    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(
      new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
    );
    app.useGlobalGuards(app.get(JwtAuthGuard));
    await app.init();
  });

  afterEach(async () => {
    await app?.close();
  });

  it.each([{ person_id: '51894' }, { person_id: '999999', username: 'OTHER_USER' }, {}])(
    'uses only the authenticated username despite query %j',
    async (scope) => {
      await request(app.getHttpServer())
        .get(path)
        .query({ lovname: 'CONTRACT_YEARS_V', lang: 'en', ...scope })
        .set('Authorization', `Bearer ${tokenFor('mixed.User')}`)
        .expect(200)
        .expect({ items: [{ code: '2026', meaning: '2026', used_value: '2026' }] });

      expect(query).toHaveBeenCalledWith(
        'SELECT * FROM XXHMC_SND_CONTRACT_YEAR_V WHERE USER_NAME = :username',
        { username: 'MIXED.USER' },
      );
      expect(hasColumn).not.toHaveBeenCalled();
    },
  );

  it('does not omit the required filter when schema metadata has no matching column', async () => {
    hasColumn.mockResolvedValue(false);
    query.mockResolvedValue([]);
    await request(app.getHttpServer())
      .get(path)
      .query({ lovname: 'CONTRACT_YEARS_V', person_id: '51894', lang: 'ar' })
      .set('Authorization', `Bearer ${tokenFor('mixed.User')}`)
      .expect(200)
      .expect({ items: [] });

    expect(query).toHaveBeenCalledWith(
      'SELECT * FROM XXHMC_SND_CONTRACT_YEAR_V WHERE USER_NAME = :username',
      { username: 'MIXED.USER' },
    );
  });

  it('caches per authenticated user and ignores person_id in the cache scope', async () => {
    query.mockImplementation((_sql: string, binds: { username: string }) =>
      Promise.resolve([{ CONTRACT_YEAR: binds.username }]),
    );
    for (const [username, personId] of [
      ['FIRST_USER', '51894'],
      ['SECOND_USER', '51894'],
      ['FIRST_USER', '999999'],
    ]) {
      await request(app.getHttpServer())
        .get(path)
        .query({ lovname: 'CONTRACT_YEARS_V', person_id: personId, lang: 'en' })
        .set('Authorization', `Bearer ${tokenFor(username)}`)
        .expect(200)
        .expect({ items: [{ code: username, meaning: username, used_value: username }] });
    }
    expect(query).toHaveBeenCalledTimes(2);
  });

  it.each([undefined, '', '   '])(
    'rejects absent or blank authenticated identity: %s',
    async (username) => {
      const attempt = request(app.getHttpServer())
        .get(path)
        .query({ lovname: 'CONTRACT_YEARS_V', person_id: '51894', username: 'OTHER_USER' });
      if (username !== undefined) attempt.set('Authorization', `Bearer ${tokenFor(username)}`);
      await attempt.expect(401);
      expect(query).not.toHaveBeenCalled();
    },
  );

  it.each([
    ['CONTRACT_YEAR_LOV', 'XXHMC_SND_CONTRACT_YEARS_V'],
    ['COUNTRY_LOV', 'XXHMC_SND_COUNTRY_LOV'],
  ])('keeps existing query username and person_id filters for %s', async (lovname, object) => {
    await request(app.getHttpServer())
      .get(path)
      .query({ lovname, person_id: '51894', username: 'query.User', lang: 'en' })
      .set('Authorization', `Bearer ${tokenFor('authenticated.User')}`)
      .expect(200);

    expect(query).toHaveBeenCalledWith(
      `SELECT * FROM ${object} WHERE user_name IN (:u0) AND person_id = :personId`,
      { u0: 'QUERY.USER', personId: '51894' },
    );
  });
});
