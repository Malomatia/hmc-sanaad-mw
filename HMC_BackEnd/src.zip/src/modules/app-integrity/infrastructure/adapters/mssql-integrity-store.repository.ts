import { Injectable, Logger, ServiceUnavailableException } from '@nestjs/common';
import { randomBytes } from 'node:crypto';
import {
  mysqlExact,
  SQL_NOW,
  UsersDbDialect,
  UsersDbService,
} from '@core/database/users-db/users-db.service';
import { SqlQueryError } from '@core/database/sql.error';
import { AttestKey } from '../../domain/attestation';
import { AttestKeyStorePort, ChallengeStorePort } from '../../domain/ports/integrity.ports';

const CHALLENGE_TABLE = 'HMC_Sanad_AttestChallenge_tbl';
const KEY_TABLE = 'HMC_Sanad_AttestKey_tbl';

/** The only shape issue() produces: 32 random bytes in base64 (44 characters). */
const CANONICAL_CHALLENGE = /^[A-Za-z0-9+/]{43}=$/;

/** Challenge expiry, `@ttl` milliseconds from now. */
const EXPIRES_AT: Record<UsersDbDialect, string> = {
  mssql: 'DATEADD(millisecond, @ttl, GETDATE())',
  mysql: 'DATE_ADD(NOW(3), INTERVAL @ttl * 1000 MICROSECOND)',
};

/** MySQL has no MERGE; its upsert relies on the UNIQUE KeyID constraint. */
const SAVE_KEY: Record<UsersDbDialect, string> = {
  mssql: `MERGE ${KEY_TABLE} AS target
          USING (SELECT @keyId AS KeyID) AS source ON target.KeyID = source.KeyID
         WHEN MATCHED THEN
              UPDATE SET LoginID = @username, PublicKey = @publicKey,
                         SignCount = @signCount, UpdatedAt = GETDATE()
         WHEN NOT MATCHED THEN
              INSERT (KeyID, LoginID, PublicKey, SignCount, CreatedAt, UpdatedAt)
              VALUES (@keyId, @username, @publicKey, @signCount, GETDATE(), GETDATE());`,
  mysql: `INSERT INTO ${KEY_TABLE} (KeyID, LoginID, PublicKey, SignCount, CreatedAt, UpdatedAt)
       VALUES (@keyId, @username, @publicKey, @signCount, NOW(), NOW())
       ON DUPLICATE KEY UPDATE LoginID = @username, PublicKey = @publicKey,
              SignCount = @signCount, UpdatedAt = NOW()`,
};

/**
 * Shared guard for both stores: a table that does not exist yet is a
 * deployment step, and is reported once rather than on every call.
 */
abstract class GuardedStore {
  protected static readonly log = new Logger('AttestationStore');
  private static readonly warned = new Set<string>();

  constructor(protected readonly db: UsersDbService) {}

  protected async guard<T>(
    table: string,
    operation: string,
    work: () => Promise<T>,
  ): Promise<T | undefined> {
    try {
      return await work();
    } catch (err) {
      const message = (err as Error)?.message ?? '';
      const missing =
        (err instanceof SqlQueryError && err.missingObject) || /invalid object name/i.test(message);

      if (missing) {
        if (!GuardedStore.warned.has(table)) {
          GuardedStore.warned.add(table);
          GuardedStore.log.warn(
            `${table} does not exist yet — device attestation cannot be recorded. ` +
              'Apply tools/app-integrity-schema.sql.',
          );
        }
        return undefined;
      }
      GuardedStore.log.warn(`${table} ${operation} failed: ${message}`);
      return undefined;
    }
  }
}

/**
 * Server-issued nonces.
 *
 * Stored, not just generated: a challenge is only worth anything if the server
 * can later say "yes, I issued that, and it has not been spent". Consuming is
 * a single conditional UPDATE so two racing requests cannot both win it.
 */
@Injectable()
export class MssqlChallengeStore extends GuardedStore implements ChallengeStorePort {
  constructor(
    db: UsersDbService,
    private readonly ttlMs: number,
  ) {
    super(db);
  }

  async issue(deviceId: string): Promise<string> {
    const value = randomBytes(32).toString('base64');
    const result = await this.guard(CHALLENGE_TABLE, 'issue', () =>
      this.db.execute(
        `INSERT INTO ${CHALLENGE_TABLE} (Challenge, LoginID, IssuedAt, ExpiresAt)
         VALUES (@value, @deviceId, ${SQL_NOW[this.db.dialect]}, ${EXPIRES_AT[this.db.dialect]})`,
        { value, deviceId, ttl: this.ttlMs },
      ),
    );
    if ((result?.rowsAffected ?? 0) < 1) {
      throw new ServiceUnavailableException('An attestation challenge could not be issued.');
    }
    return value;
  }

  async consume(value: string, deviceId?: string): Promise<boolean> {
    // The table also holds the auth state's session, grant and rate-budget
    // nonces (hF./hA./hR./hG./hB.). The value arrives from a client header, so
    // only the shape issue() produces may reach the UPDATE, compared exactly —
    // otherwise a client could spend someone's session through this route.
    if (!CANONICAL_CHALLENGE.test(value ?? '')) return false;
    const valueMatches =
      this.db.dialect === 'mysql'
        ? mysqlExact('Challenge', '@value')
        : 'Challenge COLLATE Latin1_General_100_BIN2 = @value';
    // One statement: marking it used IS the check, so a challenge cannot be
    // spent twice by two requests arriving together. The device predicate is
    // part of the same statement for the same reason.
    const result = await this.guard(CHALLENGE_TABLE, 'consume', () =>
      this.db.execute(
        `UPDATE ${CHALLENGE_TABLE}
            SET UsedAt = ${SQL_NOW[this.db.dialect]}
          WHERE ${valueMatches} AND UsedAt IS NULL AND ExpiresAt > ${SQL_NOW[this.db.dialect]}` +
          (deviceId === undefined ? '' : ' AND LoginID = @deviceId'),
        deviceId === undefined ? { value } : { value, deviceId },
      ),
    );
    return (result?.rowsAffected ?? 0) > 0;
  }
}

/**
 * Attested iOS keys.
 *
 * These must survive a restart — an in-memory map would make every iOS user
 * re-attest after each deployment, which is the flaw in the reference sample
 * this replaces.
 */
@Injectable()
export class MssqlAttestKeyStore extends GuardedStore implements AttestKeyStorePort {
  async save(key: AttestKey): Promise<void> {
    await this.guard(KEY_TABLE, 'save', () =>
      this.db.execute(
        SAVE_KEY[this.db.dialect],
        {
          keyId: key.keyId,
          username: key.username,
          publicKey: key.publicKey,
          signCount: key.signCount,
        },
      ),
    );
  }

  async find(keyId: string): Promise<AttestKey | undefined> {
    const rows = await this.guard(KEY_TABLE, 'find', () =>
      this.db.query<Record<string, unknown>>(
        `SELECT KeyID, LoginID, PublicKey, SignCount FROM ${KEY_TABLE} WHERE KeyID = @keyId`,
        { keyId },
      ),
    );
    const row = rows?.[0];
    if (!row) return undefined;
    return {
      keyId: String(row.KeyID),
      username: String(row.LoginID),
      publicKey: String(row.PublicKey),
      signCount: Number(row.SignCount ?? 0),
    };
  }

  async updateSignCount(keyId: string, signCount: number): Promise<void> {
    await this.guard(KEY_TABLE, 'updateSignCount', () =>
      this.db.execute(
        `UPDATE ${KEY_TABLE} SET SignCount = @signCount, UpdatedAt = ${SQL_NOW[this.db.dialect]}
          WHERE KeyID = @keyId`,
        { keyId, signCount },
      ),
    );
  }

  async bind(keyId: string, username: string): Promise<void> {
    await this.guard(KEY_TABLE, 'bind', () =>
      this.db.execute(
        `UPDATE ${KEY_TABLE} SET LoginID = @username, UpdatedAt = ${SQL_NOW[this.db.dialect]}
          WHERE KeyID = @keyId`,
        { keyId, username },
      ),
    );
  }
}
