import { ApprovalsOracleRepository } from './approvals.oracle.repository';
import { OracleService } from '@core/database/oracle.service';
import { OracleSchemaService } from '@core/database/oracle-schema.service';
import { ORACLE_OBJECTS } from '@shared/constants/oracle-objects';
import { OracleContractCatalog } from '@core/database/oracle-contracts';
import { OracleContractUnavailableException } from '@core/database/oracle.error';

describe('Approvals static contract handling', () => {
  it('does not cache a missing identity contract as an empty employee mapping', async () => {
    const error = new OracleContractUnavailableException(ORACLE_OBJECTS.PERSONAL_DETAILS_V, 'view columns');
    const query = jest.fn().mockResolvedValue([]);
    const resolveKeyColumn = jest.fn(async (object: string, candidates: readonly string[]) => {
      if (object === ORACLE_OBJECTS.PERSONAL_DETAILS_V) throw error;
      return candidates[0];
    });
    const repo = new ApprovalsOracleRepository(
      { query } as unknown as OracleService,
      { resolveKeyColumn } as unknown as OracleSchemaService,
    );
    for (let attempt = 0; attempt < 2; attempt++) {
      await expect(repo.getMyRequests(['MISSING-CONTRACT-TESTUSER'], 'en')).rejects.toBe(error);
    }
    expect(query).not.toHaveBeenCalled();
    expect(resolveKeyColumn).toHaveBeenCalledTimes(2);
  });

  it.each(['en', 'ar'] as const)('binds the DB-team RFMI contract without discovery for %s', async (lang) => {
    const call = jest.fn().mockResolvedValue({ p_success_flag: 'S', p_error_msg: null });
    const repo = new ApprovalsOracleRepository(
      { call } as unknown as OracleService,
      new OracleSchemaService(new OracleContractCatalog()),
    );
    await repo.requestInfo({
      username: 'test.User', lang, approvalId: '123', toUsername: 'another.User',
      itemType: 'HRSSA', itemKey: 'item-key', mode: 'REQUEST', comment: 'More details requested',
    });
    const [sql, binds] = call.mock.calls[0];
    expect(sql).toContain('BEGIN XXHMC_SND_HR_RFMI_PR(');
    expect(Object.keys(binds).sort()).toEqual([
      'p_from_user_name', 'p_to_user_name', 'p_itemtype', 'p_item_key', 'p_notification_id',
      'p_mode', 'p_comments', 'p_success_flag', 'p_error_msg', 'p_error_msg_ar',
    ].sort());
    expect(binds).toMatchObject({
      p_from_user_name: 'TEST.USER', p_to_user_name: 'ANOTHER.USER', p_notification_id: '123',
      p_mode: 'REQUEST', p_itemtype: 'HRSSA', p_item_key: 'item-key', p_comments: 'More details requested',
    });
    expect(binds).not.toHaveProperty('p_language');
    expect(call).toHaveBeenCalledTimes(1);
  });
});

/**
 * MY_REQEST_SUMMARY_V and APPROVE_SUMRY_V store the employee NUMBER, while
 * PNDNG_QID_V stores the login, so both forms have to reach the views.
 *
 * The JWT only carries the login — `identity.employeeNumber` is not populated
 * at login — so when ops 20/23 stopped trusting a client-supplied `?enum=`
 * (an employee could otherwise read another's rows), the employee-number form
 * disappeared and op 23 answered 0 rows for a caller with 8 in the view. The
 * number is resolved from the same view op 2 reads instead, which keeps it the
 * caller's own identity.
 */
describe('approvals key scoping', () => {
  const USERNAME = 'AIBRAHIM39';
  const EMPLOYEE = '037400';

  // `null` rather than `undefined` for "no row": passing undefined would
  // trigger the default parameter and quietly test the opposite case.
  function make(personalRow: Record<string, unknown> | null = { EMPLOYEE_NUMBER: EMPLOYEE }) {
    const query = jest.fn(async (sql: string) => {
      if (sql.includes(ORACLE_OBJECTS.PERSONAL_DETAILS_V)) return personalRow ? [personalRow] : [];
      return [];
    });
    const ora = { query } as unknown as OracleService;
    const schema = {
      resolveKeyColumn: jest.fn(async (_o: string, candidates: readonly string[]) => candidates[0]),
    } as unknown as OracleSchemaService;
    // the cache is static, so each case needs its own username
    return { repo: new ApprovalsOracleRepository(ora, schema), query };
  }

  /** Binds of the query issued against `object`. */
  const bindsFor = (query: jest.Mock, object: string) => {
    const call = query.mock.calls.find((c) => String(c[0]).includes(object));
    return call ? Object.values(call[1] as Record<string, unknown>) : undefined;
  };

  it('adds the resolved employee number so the requestor view matches', async () => {
    const { repo, query } = make();

    await repo.getMyRequests([`${USERNAME}-A`], 'en');

    expect(bindsFor(query, ORACLE_OBJECTS.MY_REQEST_SUMMARY_V)).toEqual([
      `${USERNAME}-A`,
      EMPLOYEE,
    ]);
  });

  it('does the same for the approver view', async () => {
    const { repo, query } = make();

    await repo.getSummary([`${USERNAME}-B`], 'en');

    expect(bindsFor(query, ORACLE_OBJECTS.APPROVE_SUMRY_V)).toEqual([
      `${USERNAME}-B`,
      EMPLOYEE,
    ]);
  });

  it('still queries with the login alone when the number cannot be resolved', async () => {
    const { repo, query } = make(null);

    await repo.getMyRequests([`${USERNAME}-C`], 'en');

    expect(bindsFor(query, ORACLE_OBJECTS.MY_REQEST_SUMMARY_V)).toEqual([`${USERNAME}-C`]);
  });

  it('reads the mapping once per caller, not once per request', async () => {
    const { repo, query } = make();

    await repo.getMyRequests([`${USERNAME}-D`], 'en');
    await repo.getMyRequests([`${USERNAME}-D`], 'en');

    const lookups = query.mock.calls.filter((c) =>
      String(c[0]).includes(ORACLE_OBJECTS.PERSONAL_DETAILS_V),
    );
    expect(lookups).toHaveLength(1);
  });
});

describe('pending request count filters', () => {
  const pendreq = 'XXHMC_SND_PNDNG_UPD_PERSON_V';
  const row = { COUNT_DATA: 7, REQUESTOR_USER_NAME: 'AIBRAHIM39', PENDING_REQ: pendreq };

  function make() {
    const query = jest.fn().mockResolvedValue([row]);
    const ora = { query } as unknown as OracleService;
    const schema = {} as OracleSchemaService;
    return { repo: new ApprovalsOracleRepository(ora, schema), query };
  }

  it('reads COUNT_DATA and the filter columns using both exact predicates', async () => {
    const { repo, query } = make();

    await expect(repo.getPendingCounts('AIBRAHIM39', pendreq)).resolves.toEqual([row]);

    expect(ORACLE_OBJECTS.PEND_COUNT).toBe('XXHMC_SND_PEND_COUNT');
    expect(query).toHaveBeenCalledTimes(1);
    expect(query).toHaveBeenCalledWith(
      expect.stringMatching(
        /SELECT COUNT_DATA, REQUESTOR_USER_NAME, PENDING_REQ\s+FROM XXHMC_SND_PEND_COUNT\s+WHERE REQUESTOR_USER_NAME = :username AND PENDING_REQ = :pendreq/,
      ),
      { username: 'AIBRAHIM39', pendreq },
    );
  });

  it('treats pendreq as a bound value, never a SQL object or fragment', async () => {
    const { repo, query } = make();
    const username = "user' OR '1'='1";
    const value = "XXHMC_SND_PNDNG_UPD_PERSON_V' OR '1'='1";

    await repo.getPendingCounts(username, value);

    const [sql, binds] = query.mock.calls[0];
    expect(sql).not.toContain(username);
    expect(sql).not.toContain(value);
    expect(sql).toContain('FROM XXHMC_SND_PEND_COUNT');
    expect(binds).toEqual({ username, pendreq: value });
  });

  it('reads fresh counts on each call and preserves empty results', async () => {
    const { repo, query } = make();
    query.mockResolvedValueOnce([row]).mockResolvedValueOnce([]);

    await expect(repo.getPendingCounts('AIBRAHIM39', pendreq)).resolves.toEqual([row]);
    await expect(repo.getPendingCounts('AIBRAHIM39', pendreq)).resolves.toEqual([]);
    expect(query).toHaveBeenCalledTimes(2);
  });
});
