import { BaseOracleRepository } from '@core/database/base.repository';

/**
 * Documented input parameters of the dependent procedures (Sanaad mapping —
 * ADD_DEPENDENT_PR / UPDATE_DEPENDENT_PR / DELETE_DEPENDENT_PR request input).
 *
 * They are kept here rather than inline because each list is long: a dependent
 * carries its identity, passport, visa, QID, sponsorship, phone and address in a
 * single call. `callSubmitProc` binds NULL for anything the caller omits; the
 * authoritative argument list (names, DATE/NUMBER/MY_TYPE types, OUTs) is the
 * static contract in OracleContractCatalog, transcribed from ALL_ARGUMENTS on
 * 2026-09-14 — none of these procedures declares p_language.
 */

/** ADD_DEPENDENT_PKG.ADD_DEPENDENT_PR (op 65). */
export const ADD_DEPENDENT_PARAMS = [
  'p_user_name',
  'p_title',
  'p_first_name',
  'p_middle_name',
  'p_last_name',
  'p_suffix',
  'p_prefix',
  'p_email_address',
  'p_relationship',
  'p_relationship_start_date',
  'p_gender',
  'p_national_identifier',
  'p_date_of_birth',
  'p_passport_number',
  'p_pp_issue_date',
  'p_pp_expiry_date',
  'p_place_of_issue',
  'p_country_of_issue',
  'p_visa_type',
  'p_visa_number',
  'p_visa_issue_date',
  'p_visa_expiry_date',
  'p_visa_validity',
  'p_id_number',
  'p_id_expiry_date',
  'p_id_issue_date',
  'p_job_as_in_qid',
  'p_type_of_sponsorship',
  'p_sponsor_contact_name',
  'p_other_sponsor',
  'p_phone_type',
  'p_phone_number',
  'p_phone_enabled',
  'p_effective_date',
  'p_main_address',
  'p_primary_flag',
  'p_address_type',
  'p_country',
  'p_address_line1',
  'p_address_line2',
  'p_address_line3',
  'p_city',
  'p_town_or_city',
  'p_region_1',
  'p_region_2',
  'p_region_3',
  'p_region1',
  'p_region2',
  'p_region3',
  'p_po_box',
  ...BaseOracleRepository.attachmentParams(),
  'p_employment_status',
  'p_comments',
] as const;

/** ADD_DEPENDENT_PKG.UPDATE_DEPENDENT_PR (op 24). */
export const UPDATE_DEPENDENT_PARAMS = [
  'p_user_name',
  'p_dependent_id',
  'p_title',
  'p_first_name',
  'p_middle_name',
  'p_last_name',
  'p_suffix',
  'p_prefix',
  'p_email_address',
  'p_relationship',
  'p_relationship_start_date',
  'p_passport_number',
  'p_date_of_issue',
  'p_date_of_expire',
  'p_place_of_issue',
  'p_country_of_issue',
  'p_visa_type',
  'p_visa_number',
  'p_date_of_issue_visa',
  'p_date_of_expire_visa',
  'p_visa_validity',
  'p_id_number',
  'p_expiry_date',
  'p_date_of_issuue_qid',
  'p_type_of_sponsorship',
  'p_name_of_contact',
  'p_name_of_sponsor',
  'p_gender',
  'p_qid_number',
  'p_date_of_birth',
  'p_effective_date',
  'p_country',
  'p_address_id',
  'p_address_line1',
  'p_address_line2',
  'p_address_line3',
  'p_city',
  'p_region_1',
  'p_region_2',
  'p_region_3',
  'p_po_box',
  'p_address_type',
  'p_phone_id',
  'p_phone_type',
  'p_phone_number',
  'p_phone_enabled',
  'p_phone_id1',
  'p_phone_type1',
  'p_phone_number1',
  'p_phone_enabled1',
  ...BaseOracleRepository.attachmentParams(),
  'p_employment_status',
  'p_comments',
] as const;

/** REMOVE_DEPENDENT_PR (op 31) — confirmed 2026-09-14, no p_language. */
export const REMOVE_DEPENDENT_PARAMS = [
  'p_user_name',
  'p_dependent_id',
  'p_relation_ship_end_date',
  'p_contact_type',
  'p_relation_ship',
  ...BaseOracleRepository.attachmentParams(),
] as const;

/** PASS_DTL_PR (op 34) — passport detail request; confirmed 2026-09-14, no p_language. */
export const PASSPORT_DETAIL_PARAMS = [
  'p_user_name',
  'p_passport_number',
  'p_date_of_issue',
  'p_date_of_expiry',
  'p_type_of_passport',
  'p_place_of_issue',
  'p_country_of_issue',
  ...BaseOracleRepository.attachmentParams(),
] as const;
